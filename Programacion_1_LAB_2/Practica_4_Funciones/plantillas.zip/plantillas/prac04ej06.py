from modulo_test import test
from ... import contenido_GC
from ... import expansion_triplete_CAG

def menu_ADN ():
    # El código de la función debe ir aquí

# –- Programa principal –-
# Ejecutar el test sólo al ejecutar el fichero (y no al importarlo)
if __name__== '__main__':
    # El código del programa principal debe ir aquí
