def leer_matriz_enteros():
    # El código de la función debe ir aquí

def mostrar_matriz_enteros(matriz):
    # El código de la función debe ir aquí

# –- Programa principal –-
# Ejecutar el test sólo al ejecutar el fichero (y no al importarlo)
if __name__== '__main__':
    # El código del programa principal debe ir aquí
